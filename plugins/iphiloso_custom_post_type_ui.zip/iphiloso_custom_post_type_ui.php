<?php 
/*
Plugin Name: iphiloso custom post 
Plugin URI: https://imtiazhabib.xyz/
Description: This is a plugin which i develop for my theme iphiloso.
Version: 1.0.0
Requires at least: 5.0
Requires PHP: 7.2
Author: John Doe
Author URI: https://imtiazhabib.xyz/
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/
function iphiloso_register_my_cpts_books() {

	/**
	 * Post Type: Books.
	 */

	$labels = [
		"name" => esc_html__( "Books", "iphiloso" ),
		"singular_name" => esc_html__( "Book", "iphiloso" ),
	];

	$args = [
		"label" => esc_html__( "Books", "iphiloso" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"rest_namespace" => "wp/v2",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"can_export" => false,
		"rewrite" => [ "slug" => "books", "with_front" => true ],
		"query_var" => true,
		"supports" => [ "title", "editor", "thumbnail" ],
		"show_in_graphql" => false,
	];

	register_post_type( "books", $args );
}

add_action( 'init', 'iphiloso_register_my_cpts_books' );

?>